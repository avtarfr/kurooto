"""Reminders: "remind me at 9 to call mum", "remind me in 20 minutes to take the tea off", /remind tomorrow 7am gym.
They arrive on Telegram. If the computer was asleep at the time, the reminder still comes when it wakes, marked
late; with Reminders with the lid shut on, your phone gets it at its time instead (lidsafe.py).

Location reminders (0.6.0, reminders.places, off by default): "remind me when I reach the library to return the
book", "remind me whenever I'm at the gym to stretch". The place's name and the text go to the Android app (a "place"
message through your call line), which keeps them and reminds you when you arrive at a place you saved there under
that name (android/.../Places.java: Android's proximity alerts, no Google services). Where your places are never
leaves the phone; this computer only knows their names.

An add-on's buttons (0.9.0, reminders.addon_buttons): a feature's reminder_buttons(what) -> [(label, callback data)]
adds a row of its own under +10 min / +1 h when a reminder fires (at most 2 buttons, each answered by that feature's
own callbacks); the snooze row is always there and first. A tap is the user's; nothing starts by itself.

The phone's place names (0.9.1, reminders.place_names, off): the Android app sends the names of the places saved on
it (names only, sealed, never where they are; modules/calls/chat.py's "place_names" op, kept in
calls/place-names.json), and a place you name is matched to one of them before it goes to the phone: "the lib" ->
"Library", "chem lab" -> "Chemistry lab". One clear match only; otherwise your words go as before. The names are used
here only, never told to an AI."""

from __future__ import annotations

import datetime as dt
import re
import time
import uuid

from kurooto.core.clock import now, parse_when
from kurooto.core.config import register_defaults
from kurooto.core.notify import Message
from kurooto.core.state import jload, jsave
from kurooto.modules.base import Command, Incoming, Intent, Module
from kurooto.modules.calls.tools import Tool, arg
from kurooto.modules.text import NEG, WHEN_DAY, stale_time, when_from

REMIND = re.compile(r"^\s*remind me\s+(?P<rest>.+)$", re.I)
WHEN_WORDS = re.compile(
    r"\b(?:in\s+\d+(?:\.\d+)?\s*[a-z]+|in\s+(?:an?|half an?)\s+[a-z]+|(?:at|by)\s+\d{1,2}(?:[:.]\d{2})?\s*(?:am|pm)?"
    r"|\d{1,2}(?:[:.]\d{2})\s*(?:am|pm)?|\d{1,2}\s*(?:am|pm)|(?:the\s+)?day after tomorrow|tomorrow|tonight|today)\b",
    re.I,
)
register_defaults(
    "reminders",
    {
        # sent to the Android app, which reminds you on arrival at a place saved there (turn on Places in the app too)
        "places": False,  # location reminders: "remind me when I reach the library to …" (needs the Android app)
        # (0.9.0) a feature (an add-on) may add its own buttons to a reminder as it fires, in a row under +10 min and
        # +1 h (for example "Order on Zepto" under "buy milk"); a tap starts it, nothing starts by itself
        "addon_buttons": True,
        # (0.9.0) during a Study mode focus, your reminders wait for its break (a reset or pause brings them at once)
        "wait_for_break": False,
        # (0.9.1) the phone app shares the names of the places you saved (names only, sealed, never where they are),
        # so "the lib" finds "Library"; used here for matching only, never told to an AI
        "place_names": False,
    },
)
PLACE_NAMES_MAX = 50  # (place_names) names kept from the phone, at most
PLACE = re.compile(
    r"^\s*remind me\s+(?P<when>whenever|every time|when|once|as soon as|(?:the )?next time)\s+"
    r"(?:i|i'm|i am)\s+(?P<verb>reach|arrive at|arrive in|get back to|get to|am at|at|get back(?=\s+home\b)"
    r"|get(?=\s+home\b))\s+(?P<place>.+?)\s*(?:[,:;]+|\s+-\s+|\s+(?:to|that|about)\s+)\s*(?P<what>\S.*)$",
    re.I,
)
ADDON_BUTTONS = 2  # (reminders.addon_buttons) at most this many buttons features add to a reminder
JOIN = re.compile(r"^(?:\s*(?:[:;,.\-–—]+|(?:to|that|about)\b))+\s*", re.I)


def tidy_what(text: str) -> str:
    """What to be reminded of, without the joins left at its start once the time is taken out: "at 6 pm: call mum",
    "- call mum", "to call mum", "about the exam" all give "call mum" / "the exam"."""
    what = JOIN.sub("", re.sub(r"\s+", " ", text).strip())
    return what.strip(" ,.;:-–—")


def place_key(name: str) -> str:
    """A place's name as it's matched (the phone's PlaceRules.key): "The Library " and "library" are the same."""
    s = re.sub(r"\s+", " ", str(name or "").strip().lower())
    s = re.sub(r"^(?:the|my|our) ", "", s)
    return re.sub(r"[.!?,;:]+$", "", s).strip()


def saved_place(said: str, names: list[str]) -> str | None:
    """(0.9.1, reminders.place_names) The one saved place `said` means, or None: the same name, else the only one
    whose words start with the words said ("lib" -> "Library", "chem lab" -> "Chemistry lab"), else the only close
    spelling. Two that fit equally: None (your words go as they are)."""
    import difflib

    k = place_key(said)
    if not k:
        return None
    keyed = {}
    for n in names:
        if place_key(n):
            keyed.setdefault(place_key(n), n)
    if k in keyed:
        return keyed[k]
    words = k.split()

    def starts(key: str) -> bool:
        kw = key.split()
        return len(kw) >= len(words) and all(a.startswith(b) for a, b in zip(kw, words, strict=False))

    hits = [n for key, n in keyed.items() if len(k) >= 2 and starts(key)]
    if len(hits) == 1:
        return hits[0]
    if hits:
        return None
    close = difflib.get_close_matches(k, list(keyed), n=2, cutoff=0.8)
    return keyed[close[0]] if len(close) == 1 else None


class Reminders(Module):
    id = "reminders"
    title = "Reminders"
    description = (
        'Plain English: "remind me at 9 to call mum". They arrive on Telegram (or the phone app), even after the '
        "laptop slept."
    )
    requires = ("telegram",)

    def __init__(self, app):
        super().__init__(app)
        # registered at once: a reminder set in the setup page's try-it box (web/tryit.py), before this feature is
        # on, still fires after a restart
        app.scheduler.action("reminders.fire", self._fire)

    def start(self):
        self.action("fire", self._fire)
        self._unpark()

    @property
    def parked_file(self):
        return self.app.paths.state / "reminders-parked.json"

    def stop(self) -> None:
        """Turned off: the reminders you set are kept (not cancelled) and set again when it's turned back on; any
        whose time passed meanwhile come then, marked late."""
        rows = jload(self.parked_file, []) or []
        for j in self.app.scheduler.jobs(f"{self.id}:"):
            if j.action == "reminders.fire":
                rows.append({"key": j.key, "at": j.next_run, "payload": j.payload})
        if rows:
            jsave(self.parked_file, rows)
        super().stop()
        self._lidsafe_poke()

    def _unpark(self) -> None:
        rows = jload(self.parked_file, []) or []
        for r in rows:
            payload = dict(r.get("payload") or {})
            if r["at"] <= time.time():
                payload["while_off"] = True
            self.app.scheduler.at(
                max(r["at"], time.time()), "reminders.fire", payload, key=r["key"], module=self.id, replace=False
            )
        self.parked_file.unlink(missing_ok=True)
        if rows:
            self._lidsafe_poke()

    def add(self, when: dt.datetime, what: str, key: str | None = None, buttons: list | None = None) -> str:
        # key: a caller that may take the reminder back (Brain's Undo, mind/study_push.py) names it "reminders:<ref>"
        # buttons: rows of (label, data) shown under it besides the snoozes (0.9.0: Study push's "Start 25 min")
        key = key if key and key.startswith("reminders:") else f"reminders:{uuid.uuid4().hex[:8]}"
        self.app.scheduler.action("reminders.fire", self._fire)
        p = {"what": what, "ref": key.split(":", 1)[1]}
        if buttons:
            p["buttons"] = [[list(b) for b in row] for row in buttons]
        self.app.scheduler.at(when, "reminders.fire", p, key=key, module=self.id)
        self.app.events.emit("reminder_set", at=when.isoformat())
        self._lidsafe_poke()
        return f"I'll remind you {when:%a %d %b at %H:%M}: {what}"

    def _lidsafe(self):
        """Reminders with the lid shut (lidsafe.py), when it's on: your call line holds the next day's reminders."""
        m = self.app.modules.get("lidsafe")
        return m if m is not None and self.app.is_on("lidsafe") else None

    def _lidsafe_poke(self) -> None:
        m = self._lidsafe()
        if m is not None:
            m.poke()

    def _fire(self, p: dict):
        ls = self._lidsafe()
        if ls is not None and ls.handed_over("reminders.fire", p):
            return  # your call line has a sealed copy: whichever side is awake now says it, once (lidsafe.py)
        if self._wait(p):
            return
        what = p.get("what", "")
        late = (
            " (late: Reminders was off)"
            if p.get("while_off")
            else " (late: the computer was asleep)"
            if p.get("late_s") or p.get("missed")
            else ""
        )
        ref = uuid.uuid4().hex[:8]
        self._snoozable(ref, what)
        rows = [[("+10 min", f"rem:{ref}:10"), ("+1 h", f"rem:{ref}:60")]]
        extra = self._addon_buttons(what)
        if extra:
            rows.append(extra)
        self.app.notify(
            f"Reminder{late}: {what}",
            kind="reminder",
            buttons=rows + [[(str(a), str(b)) for a, b in row] for row in p.get("buttons") or []],
            why="reminders.own",
            about=what,
        )
        self.app.events.emit("reminder_fired", late=bool(late))

    def _addon_buttons(self, what: str) -> list[tuple[str, str]]:
        """(reminders.addon_buttons) The buttons features add to this reminder (reminder_buttons(what)): at most
        ADDON_BUTTONS, each a short label and callback data Telegram takes (64 bytes); a feature that fails is
        skipped."""
        if self.setting("addon_buttons") is False:
            return []
        out: list[tuple[str, str]] = []
        for m in self.app.enabled():
            fn = getattr(m, "reminder_buttons", None)
            if m is self or not callable(fn):
                continue
            try:
                got = list(fn(what) or [])
            except Exception as e:
                self.app.events.emit("reminder_buttons_failed", module=m.id, error=type(e).__name__)
                continue
            for b in got:
                if isinstance(b, (tuple, list)) and len(b) == 2 and all(isinstance(x, str) and x for x in b):
                    label, data = b[0][:30], b[1]
                    if len(data.encode("utf-8")) <= 64 and ":" in data:
                        out.append((label, data))
        return out[:ADDON_BUTTONS]

    def _wait(self, p: dict) -> bool:
        """(0.9.0, reminders.wait_for_break) In a Study mode focus (modules/study.py), the reminder waits for its break:
        booked again for when the focus ends. True when it waits."""
        if not self.setting("wait_for_break") or p.get("released"):
            return False
        study = self.app.modules.get("study")
        t = study.timer() if study is not None and self.app.is_on("study") else {}
        if t.get("phase") != "focus" or not t.get("ends"):
            return False
        try:
            ends = dt.datetime.fromisoformat(t["ends"])
        except ValueError:
            return False
        if ends <= now():
            return False
        ref = str(p.get("ref") or uuid.uuid4().hex[:8])
        self.app.scheduler.at(
            ends, "reminders.fire", {**p, "released": True}, key=f"reminders:wait{ref}", module=self.id
        )
        self.app.events.emit("reminder_waits", until=ends.isoformat(timespec="minutes"))
        return True

    def release_waiting(self) -> int:
        """The reminders waiting for a focus's break, now (Study mode's timer was paused, reset or ended)."""
        n = 0
        for j in self.app.scheduler.jobs("reminders:wait"):
            if j.action == "reminders.fire" and self.app.scheduler.cancel(j.key):
                self._fire({**(j.payload or {}), "released": True})
                n += 1
        return n

    def _snoozable(self, ref: str, what: str) -> None:
        from kurooto.core.state import jload, jsave

        f = self.app.paths.state / "reminders-snooze.json"
        d = jload(f, {}) or {}
        d[ref] = what
        jsave(f, dict(list(d.items())[-200:]))

    def callbacks(self):
        return {"rem": self._snooze, "remx": self._cancel}

    def _snooze(self, ref: str, act: str) -> str:
        from kurooto.core.state import jload

        what = (jload(self.app.paths.state / "reminders-snooze.json", {}) or {}).get(ref)
        if not what:
            return "That reminder is gone."
        when = now() + dt.timedelta(minutes=int(act or 10))
        self.add(when, what)
        return f"Again at {when:%H:%M}"

    def _cancel(self, ref: str, act: str) -> str:
        gone = self.app.scheduler.cancel(f"reminders:{ref}")
        self._lidsafe_poke()
        return "Cancelled." if gone else "Already gone."

    # ---------------------------------------------------------------------------------- at a place
    def at_place(self, place: str, what: str, every: bool = False) -> str:
        """A location reminder: the place's name and the text go to the phone app, which says it on arrival."""
        place = re.sub(r"^(?:the|my|our)\s+", "", " ".join(place.split()), flags=re.I).strip(" .,!?")
        what = tidy_what(what)
        if not self.setting("places"):
            return (
                "Location reminders are off. Turn them on in Settings → Reminders (places), and Places in the phone "
                "app."
            )
        calls = self.app.modules.get("calls")
        if calls is None or not self.app.is_on("calls") or not calls.ready()[0]:
            return "Location reminders work through the Android app: set up Phone calls and pair the phone first."
        names = self.place_names()
        saved = saved_place(place, names) if names else None  # (0.9.1, place_names) "the lib" -> "Library"
        place = saved or place
        sent = calls.phone.send(Message(what, title=place, kind="place_every" if every else "place"))
        if not sent:
            return "That didn't reach the phone app. Try again in a moment."
        self.app.events.emit("reminder_place", every=every)
        how = "every time you reach" if every else "when you reach"
        if saved:
            return f"Sent to your phone: {how} {place} (saved there), it reminds you: {what}."
        return (
            f"Sent to your phone: {how} {place}, it reminds you: {what}. If {place} isn't saved in the app yet, "
            "save it there once you're at it (Places → Save where you are now)."
        )

    def place_names(self) -> list[str]:
        """(0.9.1, reminders.place_names) The names of the places saved on the phone, as it last sent them; [] while
        the switch is off or none came. Never told to an AI."""
        f = self.app.paths.state / "calls" / "place-names.json"
        if not self.setting("places") or not self.setting("place_names"):
            f.unlink(missing_ok=True)  # turned off: the names the phone sent go too
            return []
        got = jload(f, {}) or {}
        names = got.get("names") if isinstance(got, dict) else None
        return [str(n) for n in names if isinstance(n, str)][:PLACE_NAMES_MAX] if isinstance(names, list) else []

    # ------------------------------------------------------------------------------- plain English
    def intents(self):
        def match_place(text: str):
            m = PLACE.match(text)
            if not m or NEG.search(text):
                return None
            place = m["place"].strip()
            if len(place) > 40 or len(place.split()) > 5 or not tidy_what(m["what"]):
                return None
            return {"place": place, "what": m["what"], "every": m["when"].lower() in ("whenever", "every time")}

        def match(text: str):
            m = REMIND.match(text)
            if not m or NEG.search(text):
                return None
            rest = m["rest"]
            when = when_from(rest)
            if not when:
                said = stale_time(rest)  # "remind me, I didn't do it at 3": that time didn't happen, so ask
                return {"ask": said} if said else None
            what = tidy_what(WHEN_WORDS.sub("", WHEN_DAY.sub(" ", rest)))
            return {"when": when, "what": what or "you asked me to remind you"}

        def run(msg, s):
            if s.get("ask"):
                return (
                    f"When should I remind you? I didn't set one: the {s['ask']} in that is about what didn't happen "
                    'or what was planned. Say "remind me at 4:30 to …" or "remind me in 20 minutes to …".'
                )
            return self.add(s["when"], s["what"])

        return [
            Intent(
                "remind_place",
                "a reminder for when you reach a place (the phone app)",
                match_place,
                lambda msg, s: self.at_place(s["place"], s["what"], s["every"]),
                examples=("remind me when I reach the library to return the book",),
            ),
            Intent(
                "remind",
                "set a reminder",
                match,
                run,
                examples=("remind me at 9 to call mum", "remind me in 20 minutes to take the tea off"),
            ),
        ]

    def commands(self):
        return [
            Command(
                "remind",
                "a reminder (/remind 21:30 call mum, /remind tomorrow 7am gym; /remind 20 tea: in 20 min)",
                self._cmd,
            ),
            Command("reminders", "your upcoming reminders", self._list),
        ]

    def _cmd(self, msg: Incoming, arg: str) -> str:
        parts = arg.split()
        for n in (3, 2, 1):  # "tomorrow 7am gym", "in 20m tea", "21:30 call mum"
            if len(parts) >= n:
                try:
                    when = parse_when(" ".join(parts[:n]))
                except ValueError:
                    continue
                return self.add(when, tidy_what(" ".join(parts[n:])) or "you asked me to remind you")
        return (
            "Usage: /remind 21:30 call mum   (or: tomorrow 7am gym, in 20m tea; a bare number is the hour: 9 gym is "
            "the next 9:00)"
        )

    def _list(self, msg: Incoming, arg: str) -> str | None:
        jobs = self.app.scheduler.jobs("reminders:")
        if not jobs:
            return "No reminders set."
        for j in jobs[:15]:
            msg.reply(
                f"{j.when.astimezone():%a %d %b %H:%M}  {j.payload.get('what')}",
                buttons=[[("Cancel", f"remx:{j.key.split(':', 1)[1]}:x")]],
            )
        return None

    def help(self):
        return ['"remind me at 9 to …", /remind, /reminders']

    # -------------------------------------------------------------------------------------- on calls
    def call_tools(self):
        return [
            Tool(
                "add_reminder",
                'A reminder message at a time, e.g. when "18:30", "in 2 hours", "tomorrow 9am".',
                self._tool_add,
                {"when": arg(), "what": arg("what to remind them of")},
                ("when", "what"),
                offline="queue",
                hint="add_reminder sets a reminder message; schedule_call is for a reminder call instead.",
            )
        ]

    def _tool_add(self, a: dict) -> str:
        try:
            when = parse_when(str(a.get("when", "")))
        except ValueError:
            return f"I couldn't read the time {a.get('when')!r}."
        return self.add(when, str(a.get("what") or "a reminder"))

    def call_brief(self) -> dict:
        soon = [j for j in self.app.scheduler.jobs("reminders:") if j.next_run < time.time() + 86400]
        if not soon:
            return {}
        return {
            "reminders_next_24h": [
                f"{dt.datetime.fromtimestamp(j.next_run):%a %H:%M} {j.payload.get('what', '')}" for j in soon[:8]
            ]
        }
