"""Others nearby (0.8.10): a small shared signal, "someone besides you is at the desk", that one feature sets and others
read without depending on each other's code.

    set_others(app, source, on)   Face presence sets it ("face") when a second face is in view of the camera, and
                                  clears it when there's one face or the camera closes. Only the fact is kept, in
                                  memory: no face, no template, no picture, no count of who.
    others(app) -> bool           any source says so, within the last STALE_S seconds
    sources(app) -> list[str]

Voice (and Voice ID's conversation mode) can read it: while others are present, Kurooto stays out of a conversation
between people unless it's named. An event "nearby_others {on, source}" says when it changes (no other fields).

    set_view(app, faces, owner_alone)   (0.8.13) Face presence, each frame it looks at: how many faces are in view
                                  and whether the only one is the owner's. In memory, never an event.
    view(app) -> (faces, owner_alone) | None   that, when it's at most VIEW_S old (the camera may not be looking)

    set_facing(app, faces, facing)   (0.8.13, voice.listen.need_face) Face presence, each frame it looks at: how many
                                  faces, and how many of them are close and facing the camera (Face.close_facing).
                                  Kept in memory for FACING_KEEP_S as times and counts only: no picture, no numbers
                                  that describe a face, no identity.
    facing(app, since, until) -> (frames, frames_with_one)   the frames looked at in that stretch (monotonic times)
                                  and how many of them had a face close and facing it
    facing_most(app, since, until) -> int   (0.9.0) the most close and facing faces in one frame of that stretch
    last_facing(app) -> float | None   when the last such face was seen (monotonic)

    set_look(app, on)             (0.8.17, voice.listen.look_to_talk) Face presence, each frame it looks at: whether the
                                  owner's face is close and turned to the camera within the tight look angles
                                  (Face.looking). Two times only: when this run of such frames began, and the last one.
    look(app) -> (since, last)    since: None when the last frame looked at didn't have him looking (or the camera
                                  closed); last: when he was last seen looking (monotonic), None never

    set_owner(app, seen, looking, moved)   (0.9.2, voice.listen.live_prewarm / fast_live) Face presence, each frame it
                                  looks at: the owner's face recognised in it, looking at the camera (the look angles),
                                  and how much his mouth moved since his last frame (a change of two landmark ratios,
                                  None without one). Times, flags and that one change only, for FACING_KEEP_S: never
                                  the landmarks, the ratios themselves, a picture or anyone else's face.
    owner_attending(app, since, until) -> (looking, talking)   his face looked at the camera in that stretch, and his
                                  mouth moved as in talking (None: too few frames of him to tell)
    owner_looking_now(app) -> bool   his face looking at it in a frame of the last LOOK_NOW_S seconds

    set_phone_out(app, out)       (0.9.0) Brain's phone senses (mind/senses/phone.py, the places sensor): your phone
                                  just left a place you saved (out) or arrived at one (back in). Only the time it left,
                                  in memory, never the place's label (that stays in the senses' store).
    phone_out(app) -> float | None   when it left (time.time()), None when it's in or it's been PHONE_OUT_MAX_S

Nothing here authorises anything by itself. The one narrow use of the view (Voice ID's face assist, 0.8.13,
voice.speaker_id.face_assist): a voice already scored inside its "not sure" margin counts as the owner while his face
is the only one in view. A face alone never makes Kurooto act.
"""

from __future__ import annotations

import threading
import time
from collections import deque
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from kurooto.app import App

STALE_S = 120  # a signal not refreshed for this long no longer counts (a camera that closed without saying so)
VIEW_S = 5.0  # the view counts this long after the frame (Face presence looks about once a second, 3 s on battery)
FACING_KEEP_S = 60.0  # frames older than this are forgotten (a turn's window is a few seconds)
LOOK_NOW_S = 1.5  # (0.9.2) owner_looking_now: a frame this recent
# (0.9.2) talking: his mouth's landmark ratios moved at least this much between two frames (a guess: YuNet's five
# points jitter about 0.01-0.02 of the eyes' distance; a jaw opening in speech moves them several times that)
TALK_MOVE = 0.04
PHONE_OUT_MAX_S = 18 * 3600  # (0.9.0) a phone "out" never heard back from counts this long at most
_lock = threading.Lock()


def _table(app: App) -> dict[str, float]:
    t = getattr(app, "_nearby", None)
    if t is None:
        t = {}
        app._nearby = t  # type: ignore[attr-defined]
    return t


def set_others(app: App, source: str, on: bool) -> None:
    with _lock:
        t = _table(app)
        was = source in t
        if on:
            t[source] = time.monotonic()
        else:
            t.pop(source, None)
    if was != bool(on):
        try:
            app.events.emit("nearby_others", on=bool(on), source=source)
        except Exception:
            pass


def sources(app: App) -> list[str]:
    now = time.monotonic()
    with _lock:
        t = _table(app)
        return sorted(s for s, at in t.items() if now - at <= STALE_S)


def others(app: App) -> bool:
    return bool(sources(app))


def set_view(app: App, faces: int, owner_alone: bool) -> None:
    with _lock:
        app._nearby_view = (int(faces), bool(owner_alone), time.monotonic())  # type: ignore[attr-defined]


def clear_view(app: App) -> None:
    with _lock:
        app._nearby_view = None  # type: ignore[attr-defined]
        app._nearby_look = (None, getattr(app, "_nearby_look", (None, None))[1])  # type: ignore[attr-defined]


def set_look(app: App, on: bool, at: float | None = None) -> None:
    """One frame looked at (at: its monotonic time, None: now): the owner looking at the camera in it or not."""
    t = time.monotonic() if at is None else float(at)
    with _lock:
        since, last = getattr(app, "_nearby_look", (None, None))
        app._nearby_look = (t if since is None else since, t) if on else (None, last)  # type: ignore[attr-defined]


def look(app: App) -> tuple[float | None, float | None]:
    with _lock:
        return getattr(app, "_nearby_look", (None, None))


def view(app: App) -> tuple[int, bool] | None:
    with _lock:
        v = getattr(app, "_nearby_view", None)
    if v is None or time.monotonic() - v[2] > VIEW_S:
        return None
    return v[0], v[1]


def _looks(app: App) -> deque:
    d = getattr(app, "_nearby_looks", None)
    if d is None:
        d = deque(maxlen=600)  # (time, faces, close and facing): at most 10 a second for a minute
        app._nearby_looks = d  # type: ignore[attr-defined]
    return d


def set_facing(app: App, faces: int, facing: int, at: float | None = None) -> None:
    """One frame looked at (at: its monotonic time, None: now)."""
    now = time.monotonic()
    t = now if at is None else float(at)
    with _lock:
        d = _looks(app)
        d.append((t, int(faces), int(facing)))
        while d and now - d[0][0] > FACING_KEEP_S:
            d.popleft()
        if facing > 0 and t >= (getattr(app, "_nearby_facing_at", None) or 0.0):
            app._nearby_facing_at = t  # type: ignore[attr-defined]


def facing(app: App, since: float, until: float | None = None) -> tuple[int, int]:
    """Frames looked at between since and until (monotonic; until None: now), and how many had a face close and
    facing the camera."""
    hi = time.monotonic() if until is None else until
    with _lock:
        rows = [r for r in _looks(app) if since <= r[0] <= hi]
    return len(rows), sum(1 for r in rows if r[2] > 0)


def facing_most(app: App, since: float, until: float | None = None) -> int:
    """(0.9.0, voice.listen.count_voices) The most faces close and facing the camera in any one frame between since
    and until (monotonic): a count only."""
    hi = time.monotonic() if until is None else until
    with _lock:
        return max((r[2] for r in _looks(app) if since <= r[0] <= hi), default=0)


def facing_many(app: App, within: float = 10.0) -> bool:
    """(0.9.0, notify.guests_hold) Two or more faces close and facing the camera in a frame of the last `within`
    seconds: someone besides you could read the screen. Counts only."""
    lo = time.monotonic() - within
    with _lock:
        return any(r[0] >= lo and r[2] >= 2 for r in _looks(app))


def last_facing(app: App) -> float | None:
    with _lock:
        return getattr(app, "_nearby_facing_at", None)


def _owner(app: App) -> deque:
    d = getattr(app, "_nearby_owner", None)
    if d is None:
        d = deque(maxlen=600)  # (time, seen, looking, moved)
        app._nearby_owner = d  # type: ignore[attr-defined]
    return d


def set_owner(app: App, seen: bool, looking: bool, moved: float | None = None, at: float | None = None) -> None:
    """(0.9.2) One frame looked at: his face in it (recognised), looking at the camera, his mouth's change."""
    now = time.monotonic()
    t = now if at is None else float(at)
    with _lock:
        d = _owner(app)
        d.append((t, bool(seen), bool(seen and looking), None if moved is None or not seen else float(moved)))
        while d and now - d[0][0] > FACING_KEEP_S:
            d.popleft()


def owner_attending(app: App, since: float, until: float | None = None) -> tuple[bool, bool | None]:
    """(0.9.2) (looking, talking) over the frames between since and until: looking, any frame of his face looking at the
    camera; talking, at least two mouth changes known and one of them TALK_MOVE or more (None: fewer than two)."""
    hi = time.monotonic() if until is None else until
    with _lock:
        rows = [r for r in _owner(app) if since <= r[0] <= hi]
    looking = any(r[2] for r in rows)
    moves = [r[3] for r in rows if r[3] is not None]
    if len(moves) < 2:
        return looking, None
    return looking, any(m >= TALK_MOVE for m in moves)


def owner_looking_now(app: App) -> bool:
    lo = time.monotonic() - LOOK_NOW_S
    with _lock:
        d = _owner(app)
        return bool(d) and d[-1][0] >= lo and d[-1][2]


def set_phone_out(app: App, out: bool, at: float | None = None) -> None:
    """(0.9.0) Your phone left a saved place (out) or arrived at one, or you're back at the desk (not out)."""
    with _lock:
        app._nearby_phone = (time.time() if at is None else float(at)) if out else None  # type: ignore[attr-defined]


def phone_out(app: App) -> float | None:
    with _lock:
        at = getattr(app, "_nearby_phone", None)
    return at if at is not None and time.time() - at <= PHONE_OUT_MAX_S else None
