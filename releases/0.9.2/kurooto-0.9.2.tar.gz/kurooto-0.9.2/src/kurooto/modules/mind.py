"""Brain (0.8.0): Kurooto's mind, as a feature. Off until you turn it on; turned off, Kurooto is exactly as in 0.7.

This module starts the scorekeeper (kurooto/mind/scorekeeper.py) as a process of its own, starts it again if it dies
(waiting 1 s, then longer, up to a minute), and ends it with Kurooto. It mirrors a few kinds of events into the mind
log (ids and numbers only: mind/log.py MIRRORED), and answers /mind. Everything it keeps is in `<state>/mind/`, on
this computer only. Turning it off offers to delete that (Delete Brain's data / Keep it); nothing is deleted
otherwise.

The optional hardened mode (tools/mind_harden.sh, Linux and macOS): the scorekeeper runs as a system user of its own,
started by systemd or launchd, so not even a program running as you can change the log. Kurooto then only reads it.

The parts that grow from the spine (stages 02-17) each have their own switch, `mind.<part>.on`, and come with Brain.
"""

from __future__ import annotations

import asyncio
import datetime as dt
import os
import shutil
import subprocess
import sys
import threading
import time
from pathlib import Path

from kurooto import mind
from kurooto.core import here
from kurooto.core.config import register_defaults
from kurooto.core.events import subscribe
from kurooto.core.state import jload, jsave
from kurooto.mind import (
    act,
    attention,
    beliefs,
    breaks,
    dream,
    feelings,
    forecast,
    gate,
    improve,
    journal,
    measure,
    mood,
    pest,
    presence_forecast,
    promises,
    signals,
    sleep,
    status,
    stimulation,
    story,
    study_push,
    tone,
    workspace,
)
from kurooto.mind import console as _console  # noqa: F401 (its setting, mind.console.on, the Brain console)
from kurooto.mind import log as mlog
from kurooto.mind import plans as mind_plans
from kurooto.mind import play as mind_play
from kurooto.mind import precedents as mind_precedents
from kurooto.mind import register as _register  # noqa: F401 (its setting, mind.register.on: one temperament)
from kurooto.mind.harness import indicators as harness_indicators
from kurooto.mind.harness import run as harness_run
from kurooto.mind.lab import report as lab_report
from kurooto.mind.lab import runner as lab_runner
from kurooto.mind.plans import tree as plans_tree
from kurooto.mind.senses import activity as senses_activity
from kurooto.mind.senses import intero as senses_intero
from kurooto.mind.senses import phone as senses_phone
from kurooto.mind.senses import store as senses_store
from kurooto.mind.skills import demos as skill_demos
from kurooto.mind.skills import distill as skill_distill
from kurooto.mind.skills import finetune as skill_finetune
from kurooto.mind.skills import library as skill_library
from kurooto.mind.tom import attention_of as tom_attention
from kurooto.mind.tom import beliefs_about as tom_beliefs
from kurooto.mind.tom import goals as tom_goals
from kurooto.mind.tom import knowledge as tom_knowledge
from kurooto.mind.tom import model as tom_model
from kurooto.mind.tom import prefs as tom_prefs
from kurooto.mind.tom import results as tom_results
from kurooto.modules.base import Command, Incoming, Intent, Module

register_defaults(
    "mind",
    {
        "hardened": False,  # the scorekeeper runs as its own user (tools/mind_harden.sh; its marker file does the same)
        "anchor_every": 1000,  # the log's head is written down every this many records (and once a day)
    },
)
# (0.9.0) Brain's read-only tools for every AI and calls: this week's plan, when you're likely free next (words, never
# numbers), your precedents. Never the read, a mood, tone, the forecast of you or a sense reading
register_defaults("mind", {"tools": {"on": True}})

BACKOFF_MAX_S = 60  # a scorekeeper that keeps dying is started again at most this often
STEADY_S = 300  # one that ran this long starts the wait from 1 s again
END_S = 5  # it's asked to stop, and killed if it hasn't after this long
CONFIRM_S = 7 * 86400  # Delete Brain's data works this long after it was offered


def free_words(app) -> str:
    """(0.9.0) Brain's presence forecast in words: "likely free from 16:00", never its chances (R7). Also what
    schedule_call's when="when I'm free" uses (modules/calls)."""
    from kurooto.mind import presence_forecast as pf

    if not pf.on(app):
        return "Brain's presence forecast is off (mind.presence_forecast.on)."
    if pf.free_now(app):
        return "Likely free now."
    nf = pf.next_free(app)
    if nf is None:
        return "Not likely free in the next hours, as far as Brain can tell."
    at = nf[0]
    when = f"{at:%H:%M}" if at.date() == dt.date.today() else f"{at:%a %H:%M}"
    return f"Likely free from {when}."


class Mind(Module):
    id = mind.MODULE
    title = "Brain"
    description = (
        "Kurooto's mind: a tamper-evident log of what it saw and decided, kept by a separate process the AI can't "
        "change. The parts that grow from it (forecasts, drives, a journal) each have their own switch."
    )
    privacy = "Stays on this computer: ids, kinds and numbers, never the words of your messages."
    processes = ("kurooto.mind.scorekeeper",)
    extra = True  # in no preset ("Everything" too): on only when you pick it yourself

    def __init__(self, app):
        super().__init__(app)
        self._unsub = None
        self._proc: subprocess.Popen | None = None
        self.restarts = 0
        self.started_at = 0.0

    @property
    def dir(self) -> Path:
        return self.app.paths.state / "mind"

    # ------------------------------------------------------------------------------------------ lifecycle
    def start(self) -> None:
        if self._unsub is None:
            self._unsub = subscribe(self._mirror)
        status.start(self.app)  # 0.8.14: one status stream for the being, the phone's Views and add-ons
        self.every("gate", "every 1m", lambda p: gate.release(self.app) if gate.on(self.app) else 0)  # held messages
        self.every("pest", "every 1m", lambda p: pest.sweep(self.app) if mind.on(self.app) else 0)  # ignored an hour
        # stage 04 (shadow mode: computed, logged and shown, nothing depends on it yet); each part has its own switch
        self.every("signals", "hourly", self._signals)  # the day's numbers, then today's read
        self.every("tone", "hourly", lambda p: tone.batch(self.app) if mind.on(self.app) else 0)
        self.every("tone_roll", "daily 04:05", lambda p: tone.roll(self.app) if mind.on(self.app) else False)
        self.every("score", "daily 20:55", lambda p: mood.run_score(self.app) if mind.on(self.app) else False)
        self.every("forecast", "daily 21:00", lambda p: mood.run_forecast(self.app) if mind.on(self.app) else None)
        self.every("ask", "daily 19:30", lambda p: mood.ask(self.app) if mind.on(self.app) else False)
        # stage 05: the body budget, its promises and its feelings (each its own switch)
        self.every("budget", "every 5m", lambda p: measure.run(self.app) if mind.on(self.app) else False)
        self.every("promises", "every 5m", lambda p: promises.review(self.app) if mind.on(self.app) else {})
        self.every("feelings", "hourly", lambda p: feelings.tick(self.app) if mind.on(self.app) else None)
        self.every("feeling_say", "daily 17:30", lambda p: feelings.say(self.app) if mind.on(self.app) else False)
        # 0.8.8: speaking up about a finding or a risk (off by default), concern for what it looks after, a body
        self.every("feeling_vocal", "hourly", lambda p: feelings.vocal(self.app) if mind.on(self.app) else False)
        workspace.register_bidder("concern", feelings.bids)
        self.every("stimulation", "every 1m", lambda p: stimulation.tick(self.app) and None, thread=True)
        self.every("act_digest", "weekly sun 19:10", lambda p: act.digest(self.app) if mind.on(self.app) else False)
        # stage 07: the day's journal, then the checker's own nightly self-check against corrupted copies of it
        self.every("journal", "daily 23:40", self._journal)
        # stage 08: the week's chapter on Sunday night, the summary rebuilt every night, old lines about you let go
        self.every(
            "story_week", "weekly sun 23:55", lambda p: story.write_week(self.app) if mind.on(self.app) else None
        )
        self.every("story_night", "daily 23:50", self._story_night)
        # stage 10: the workspace's cycle (and on an alarm or call, at once), then the beliefs from today's read
        self.every("workspace", "every 1m", lambda p: workspace.tick(self.app) and None)  # 0.8.14: and the door
        self.every("beliefs", "hourly", lambda p: beliefs.sync(self.app) if mind.on(self.app) else 0)
        # stage 11: the overnight lab (on the charger, lid open) and its morning note
        workspace.register_bidder("lab", lab_report.bid)
        self.every("lab", "daily 01:30", lambda p: self._heavy("lab", "gpu", lab_runner.nightly, True), thread=True)
        self.every("lab_digest", "daily 07:40", self._lab_digest, thread=True)
        # stage 17: free-time play (off by default) and its Sunday note; case law is asked about when a call comes up
        self.every(
            "play", "daily 02:10", lambda p: self._heavy("play", "cpu", mind_play.run_session, True), thread=True
        )
        self.every("play_digest", "weekly sun 19:30", lambda p: mind_play.weekly(self.app) and None)
        # stage 15: week-scale plans, remade each morning; one line on Sunday evening at most
        self.every("plans", "daily 06:10", lambda p: self._heavy("plans", "cpu", mind_plans.run), thread=True)
        self.every("plans_weekly", "weekly sun 19:20", lambda p: mind_plans.weekly(self.app) and None, thread=True)
        # stage 14: the model of their mind (what they know, believe, want, prefer, attend to) and false-belief checks
        self.every(
            "tom_sync", "hourly", lambda p: self._heavy("tom_sync", "light", lambda a: self._tom_sync()), thread=True
        )
        self.every("tom_check", "every 30m", lambda p: tom_beliefs.check(self.app) and None)
        # stage 13: a body: its own machine every minute, the activity stream (opt-in), the totals kept 7 days raw
        workspace.register_bidder("body", senses_intero.bids)
        self.every("intero", "every 1m", lambda p: senses_intero.tick(self.app) and None, thread=True)
        self.every("activity", "every 1m", lambda p: senses_activity.tick(self.app) and None, thread=True)
        self.every("activity_poll", "every 5m", lambda p: senses_activity.poll(self.app) and None, thread=True)
        self.every("senses_roll", "daily 04:30", lambda p: senses_store.rollup(self.app) and None, thread=True)
        # stage 12: skills from tasks that worked out, the ones it noticed you repeat, retirement, the weekly fine-tune
        self.every(
            "skills_distill",
            "daily 03:10",
            lambda p: self._heavy("distill", "cpu", skill_distill.nightly, True),
            thread=True,
        )
        self.every("skills_offer", "daily 18:20", lambda p: skill_demos.offer(self.app) and None)
        self.every("skills_retire", "daily 04:20", lambda p: skill_library.retire_stale(self.app) and None, thread=True)
        self.every(
            "finetune", "daily 03:40", lambda p: self._heavy("finetune", "gpu", skill_finetune.run, True), thread=True
        )
        # 0.8.14: dreaming about the day (cards, lessons; in the night, after the journal and the story), one morning
        # line about the subject it's most uneasy about, and a check-in that comes early when the day surprises it
        self.every("dream", dream.WHEN, lambda p: dream.nightly(self.app) and None, thread=True)
        self.every("study_push", self._study_push_when(), lambda p: study_push.push(self.app) and None, thread=True)
        self.every("surprise", "every 15m", lambda p: forecast.surprise_tick(self.app) and None, thread=True)
        # 0.8.16: when you'll be at your desk and free, forecast hours ahead and scored against the senses
        self.every("presence", "every 15m", lambda p: presence_forecast.tick(self.app) and None, thread=True)
        # stage 09: the hidden harness, nightly and on the charger only
        self.every(
            "harness",
            "daily 02:40",
            lambda p: self._heavy("harness", "cpu", harness_run.nightly, True) if mind.on(self.app) else None,
            thread=True,
        )
        # 0.8.14: Kurooto sleeps in your sleep window; its heavy work yields to yours and prefers its sleep
        self.every("sleep", "every 1m", lambda p: sleep.tick(self.app) and None)
        self.every("yield", "every 5m", lambda p: senses_intero.retry(self.app) and None, thread=True)
        self.every("contention", "every 1m", lambda p: senses_intero.contention_tick(self.app) and None, thread=True)
        gates = getattr(getattr(self.app, "jobs", None), "gates", None)
        if gates is not None and self._job_gate not in gates:
            gates.append(self._job_gate)

    def _heavy(self, name: str, cost: str, fn, nightly: bool = False) -> None:
        """The Brain's own heavy work: it starts when the body allows (mind/senses/intero.py: gated), else later."""
        senses_intero.gated(self.app, name, cost, lambda: fn(self.app), nightly=nightly)

    def _job_gate(self, info: dict) -> float | None:
        """core/jobs.py asks before automatic work starts: the Brain's own requests (why "mind.") wait for the body;
        on the model on this computer they're GPU work, else light."""
        if not str(info.get("why") or "").startswith("mind.") or not senses_intero.yield_on(self.app):
            return None
        brain = info.get("brain") or self.app.settings.get("brain.main") or ""
        go, _ = senses_intero.ok(self.app, "gpu" if brain == "ollama" else "light")
        return None if go else time.time() + 600

    def _study_push_when(self) -> str:
        spec = str(self.app.settings.get("mind.study_push.when") or "daily 07:55")
        return spec if spec.startswith(("daily ", "every ", "weekly ")) else "daily 07:55"

    def dreaming_section(self, send: bool) -> tuple[str, list]:
        """The morning message's part from Brain's night: the voice line, the cards and the lessons (mind/dream.py)."""
        return dream.section(self.app, send)

    def _signals(self, payload: dict | None = None) -> int:
        """Hourly: the day's numbers go to the scorekeeper, then today's read is made from them."""
        if not mind.on(self.app):
            return 0
        n = signals.run(self.app, payload)
        mood.run_read(self.app, payload)
        return n

    def stop(self) -> None:
        gates = getattr(getattr(self.app, "jobs", None), "gates", None)
        if gates is not None and self._job_gate in gates:
            gates.remove(self._job_gate)
        if self._unsub is not None:
            self._unsub()
            self._unsub = None
        status.stop(self.app)
        c = mind._clients.get(id(self.app))
        if c is not None:
            c.flush(2.0)
        super().stop()
        self._end()

    def turned_off(self) -> None:
        """Brain was just turned off: say what it kept, and offer to delete it."""
        try:  # 0.8.14: whatever waited at the workspace's door goes now, as it would have without Brain
            workspace.flush(self.app)
        except Exception as e:
            self.app.events.emit("mind_door_failed", error=f"flush: {type(e).__name__}"[:60])
        if not self.dir.exists():
            return
        n = mlog.MindLog(self.dir / "log.db").count()
        asked = int(time.time())
        self.app.notify(
            f"Brain is off. What it kept stays on this computer ({n:,} records in its log, and its scores) until you "
            "delete it. Turning it on again carries on from there.",
            kind="result",
            why="mind.off",
            buttons=[[("Delete Brain's data", f"mnd:{asked}:delete"), ("Keep it", "mnd:0:keep")]],
        )

    def _mirror(self, rec: dict) -> None:
        """An event, as it happens (core/events.py): the mirrored kinds go to the scorekeeper. Never blocks."""
        kind = str(rec.get("kind") or "")
        if kind in ("alarm_rang", "call_rang") and workspace.on(self.app):  # a high-priority event: an immediate cycle
            workspace.poke(self.app, f"event:{kind}", "event", kind.replace("_", " "))
        if mlog.mirrored(kind) and mind.on(self.app):
            mind.connect(self.app).report(kind, rec)
        breaks.on_event(self.app, rec)  # 0.8.14: a session ending or you coming back is a natural break
        here.on_event(self.app, rec)  # (0.9.0) you used the phone app: owner_here via phone (core/here.py)
        if kind in sleep.EVENTS:  # you waking it, or getting up (mind/sleep.py)
            sleep.on_event(self.app, rec)

    # ------------------------------------------------------------------------------------------ the process
    def hardened(self) -> bool:
        """The scorekeeper runs as its own user (tools/mind_harden.sh leaves the marker; mind.hardened forces it)."""
        return bool(self.setting("hardened")) or (self.dir / "hardened").exists()

    def _cmd(self) -> list[str]:
        return [
            sys.executable,
            "-m",
            "kurooto.mind.scorekeeper",
            "--dir",
            str(self.dir),
            "--parent",
            str(os.getpid()),
            "--anchor-every",
            str(int(self.setting("anchor_every") or 1000)),
        ]

    def _spawn(self) -> subprocess.Popen:
        self.dir.mkdir(parents=True, exist_ok=True)
        mlog.private(self.dir, 0o700)
        self.app.paths.logs.mkdir(parents=True, exist_ok=True)
        err = open(self.app.paths.logs / "mind-scorekeeper.log", "a", encoding="utf-8")  # noqa: SIM115 (the child's)
        kw: dict = {"stdin": subprocess.DEVNULL, "stdout": subprocess.DEVNULL, "stderr": err}
        if sys.platform == "win32":
            kw["creationflags"] = subprocess.CREATE_NO_WINDOW
        try:
            return subprocess.Popen(self._cmd(), **kw)  # noqa: S603 (our own module, our own interpreter)
        finally:
            err.close()

    def _end(self) -> None:
        p, self._proc = self._proc, None
        if p is None or p.poll() is not None:
            return
        try:
            p.terminate()
            p.wait(END_S)
        except subprocess.TimeoutExpired:
            p.kill()
            p.wait(END_S)
        except OSError:
            pass

    async def background(self, stop: asyncio.Event) -> None:
        """Keep the scorekeeper running while Brain is on (hardened: systemd or launchd does, and this only waits)."""
        wait = 1.0
        try:
            while not stop.is_set():
                if not mind.on(self.app):  # turned off meanwhile: Kurooto stops this task too
                    break
                if self.hardened():
                    await self._sleep(stop, 60)
                    continue
                self._proc = await asyncio.to_thread(self._spawn)
                self.started_at = time.monotonic()
                self.app.events.emit("mind_keeper_started", pid=self._proc.pid)
                while self._proc is not None and self._proc.poll() is None and not stop.is_set():
                    await self._sleep(stop, 1)
                if stop.is_set() or self._proc is None:
                    break
                code = self._proc.returncode
                self.restarts += 1
                self.app.events.emit("mind_keeper_exited", code=code)
                if time.monotonic() - self.started_at >= STEADY_S:
                    wait = 1.0
                await self._sleep(stop, wait)
                wait = min(BACKOFF_MAX_S, wait * 2)
        finally:
            await asyncio.to_thread(self._end)

    @staticmethod
    async def _sleep(stop: asyncio.Event, secs: float) -> None:
        try:
            await asyncio.wait_for(stop.wait(), timeout=secs)
        except TimeoutError:
            pass

    # ------------------------------------------------------------------------------------------ what you see
    def health(self) -> tuple[bool, str]:
        c = mind.connect(self.app)
        up, _ = c.running()
        if not up:
            return False, "its scorekeeper isn't running (it's started again by itself; /mind says more)"
        return True, ""

    def dreaming_lines(self) -> list[str]:
        """The morning message's line: where the log is, so a rewritten log can be caught against what you saw."""
        c = mind.connect(self.app)
        st = c.state()
        if not st["head"]:
            return []
        return [f"Brain's log: {st['records']:,} records, head #{st['head']} {st['hash'][:12]}."]

    def call_tools(self):
        """(0.9.0, mind.tools.on) What any AI may read of Brain: words only (R7)."""
        if not mind.part_on(self.app, "tools"):
            return []
        from kurooto.modules.calls.tools import Tool

        return [
            Tool(
                "brain_plan",
                "Brain's suggestion for this week: hours a day per deadline or milestone, and which may be missed at "
                "their pace. A suggestion, not a to-do.",
                lambda a: mind_plans.view(self.app),
                writes=False,
                hint="For 'what should I work on this week?', call brain_plan and quote it.",
            ),
            Tool(
                "brain_free_time",
                "When they're likely free next (at the desk, not in class, not asleep, not on a call), from Brain's "
                "presence forecast, in words.",
                lambda a: free_words(self.app),
                writes=False,
                hint="For 'when am I free?', call brain_free_time; schedule_call also takes when='when I'm free'.",
            ),
            Tool(
                "brain_precedents",
                "How they settled earlier judgement calls between two of their values (their precedents).",
                lambda a: mind_precedents.listing(self.app),
                writes=False,
            ),
        ]

    def commands(self) -> list[Command]:
        return [
            Command(
                "capabilities",
                "what Kurooto can do, measured on tasks it has never seen; /capabilities run measures now",
                self.capabilities_cmd,
                usage="/capabilities [run]",
            ),
            Command(
                "indicators",
                "Functional indicators (not evidence of sentience): ablation tests, with what was measured",
                self.indicators_cmd,
            ),
            Command(
                "story",
                "Kurooto's one life story: its fixed core and what it has lived lately; /story strike <week> <line>",
                self.story_cmd,
                usage="/story [strike <YYYY-Www> <line>]",
            ),
            Command(
                "mindjournal",
                "Kurooto's own journal of its states, reasons and mistakes, every line checked against its log",
                self.journal_cmd,
                usage="/mindjournal [yesterday | <date> | strike <line> [date]]",
            ),
            Command(
                "autonomy",
                "what Kurooto may do without asking, by kind of action; /autonomy classify <action> R1",
                self.autonomy_cmd,
                usage="/autonomy [classify <action> <R0-R3>]",
            ),
            Command("budget", "Brain's body budget: its variables, drive, reward and current feeling", self.budget_cmd),
            Command(
                "wake", "wake Kurooto now (asleep, its camera and microphone are off: this wakes them)", self.wake_cmd
            ),
            Command("promises", "what Kurooto said it would do, and whether it did", self.promises_cmd),
            Command(
                "mood",
                "how Brain reads you and what it expects of tomorrow (it only watches for now)",
                self.mood_cmd,
                usage="/mood",
            ),
            Command(
                "precedents",
                "how Kurooto settles a call between your values: /precedents, edit <id> <ruling>, delete <id>",
                self.precedents_cmd,
                usage="/precedents [edit <id> <a|b|both|depends>|delete <id>]",
            ),
            Command(
                "play",
                "Kurooto's free-time exploring (off by default): /play, /play outputs, /play useful <id>",
                self.play_cmd,
                usage="/play [outputs|useful <id>]",
            ),
            Command(
                "plan",
                "this week's suggested hours and which milestones may be missed: /plan, /plan effort <id> <hours>",
                self.plan_cmd,
                usage="/plan [effort <id> <hours>]",
            ),
            Command(
                "model",
                "what Kurooto thinks you know, believe, want and prefer; /model wrong <id>, /model forget <id>",
                self.model_cmd,
                usage="/model [knowledge|belief|goal|pref|attention|wrong <id>|forget <id>]",
            ),
            Command(
                "senses",
                "what Kurooto senses: its machine, your activity (if on), your phone's sensors (each opt-in)",
                self.senses_cmd,
                usage="/senses [on|off <sensor>|forget [sensor]|wifi label <id> <name>|body]",
            ),
            Command(
                "learned",
                "the skills Kurooto has learned: /learned, /learned run <name> <text>, /learned retire <name>",
                self.learned_cmd,
                usage="/learned [run <name> <text>|retire <name>]",
            ),
            Command(
                "lab",
                "the overnight lab: /lab, /lab protocol <project>, /lab run <project>, /lab add <folder>, /lab results",
                self.lab_cmd,
                usage="/lab [protocol <project> [approve]|run <project>|add <folder>|results]",
            ),
            Command(
                "improve",
                "Kurooto improving itself through gated proposals: /improve, /improve promote <id>",
                self.improve_cmd,
                usage="/improve [promote <id>]",
            ),
            Command(
                "thinking",
                "what Kurooto has on its mind right now, why, and how well it predicts its own attention; "
                "/thinking pin|unpin|mute|veto|unveto <item or part>",
                self.thinking_cmd,
                usage="/thinking [pin|unpin|mute|veto|unveto <item>]",
            ),
            Command(
                "beliefs",
                "what Kurooto believes, with where each belief came from and how sure it is; /beliefs <topic>",
                self.beliefs_cmd,
                usage="/beliefs [topic]",
            ),
            Command(
                "mind",
                "Brain: its scorekeeper, its log and whether the log checks out; /mind verify checks all of it; "
                "/mind gate shows what it held back or removed from messages today; /mind measures what each part "
                "changed and the reply latency; /mind backfill feeds it the past",
                self.cmd,
                usage="/mind [verify | gate | measures | backfill [dry | run [source] | verify | forget [source]]]",
            ),
        ]

    def _lab_digest(self, payload: dict | None = None) -> bool:
        """Morning: what the lab did last night, nulls as much as wins (once per night)."""
        if not mind.part_on(self.app, "lab"):
            return False
        last = jload(self.app.paths.state / "lab" / "last-night.json", {}) or {}
        if not last or last.get("told") == last.get("at"):
            return False
        text = lab_report.digest(self.app)
        if not text:
            return False
        last["told"] = last.get("at")
        jsave(self.app.paths.state / "lab" / "last-night.json", last)
        self.app.notify(text, kind="info", why="mind.lab")
        return True

    def _journal(self, payload: dict | None = None) -> dict | None:
        if not mind.on(self.app):
            return None
        out = journal.write_day(self.app)
        journal.selfcheck(self.app)
        return out

    def _story_night(self, payload: dict | None = None) -> str | None:
        if not mind.on(self.app):
            return None
        story.expire(self.app)
        return story.rebuild(self.app)

    def capabilities_cmd(self, msg: Incoming, arg: str) -> str:
        if (arg or "").strip().lower() == "run":
            if not mind.part_on(self.app, "harness"):
                return "The harness is off (mind.harness.on, with Brain)."
            res = harness_run.run(self.app)
            harness_run.report(self.app, res)
            return harness_run.capabilities(self.app)
        return harness_run.capabilities(self.app)

    def indicators_cmd(self, msg: Incoming, arg: str) -> str:
        if not mind.part_on(self.app, "harness"):
            return "The harness is off (mind.harness.on, with Brain)."
        return harness_indicators.page(self.app)

    def story_cmd(self, msg: Incoming, arg: str) -> str:
        words = (arg or "").split()
        if len(words) == 3 and words[0].lower() == "strike" and words[2].isdigit():
            return story.strike(self.app, words[1], int(words[2]))
        return story.status(self.app)

    def journal_cmd(self, msg: Incoming, arg: str) -> str:
        import datetime as dt

        from kurooto.core.clock import now

        if not mind.part_on(self.app, "journal"):
            return "The journal is off (mind.journal.on, with Brain)."
        words = (arg or "").split()
        today = now().date()
        if words and words[0].lower() == "strike" and len(words) >= 2 and words[1].isdigit():
            day = dt.date.fromisoformat(words[2]) if len(words) > 2 else today
            return journal.strike(self.app, day, int(words[1]))
        day = today
        if words and words[0].lower() == "yesterday":
            day = today - dt.timedelta(days=1)
        elif words:
            try:
                day = dt.date.fromisoformat(words[0])
            except ValueError:
                return "Say a date like 2026-10-25, yesterday, or strike <line> [date]."
        e = journal.read_day(self.app, day)
        if e is None:
            e = journal.write_day(self.app, day) and journal.read_day(self.app, day)
        if e is None:
            return f"No journal for {day.isoformat()} yet."
        return (
            journal.render(e)
            + f"(checked: {e['facts']} facts, {e['rejected']} lines the model wrote were replaced by the fixed words.)"
        )

    def autonomy_cmd(self, msg: Incoming, arg: str) -> str | None:
        words = (arg or "").split()
        if len(words) == 3 and words[0].lower() == "classify":
            return act.classify_cmd(self.app, words[1], words[2])
        text, buttons = act.status(self.app)
        msg.reply(text, buttons or None)
        return None

    def budget_cmd(self, msg: Incoming, arg: str) -> str:
        from kurooto.mind import report

        return report.budget_text(self.app)

    def _tom_sync(self, payload: dict | None = None) -> int:
        if not tom_model.on(self.app):
            return 0
        n = tom_knowledge.from_notes(self.app) + tom_knowledge.from_quiz(self.app) + tom_goals.sync_deadlines(self.app)
        n += tom_goals.from_past(self.app)
        n += tom_prefs.sync(self.app) + len(tom_goals.infer_intentions(self.app))
        tom_attention.remember(self.app)
        return n

    def plan_cmd(self, msg: Incoming, arg: str) -> str:
        if not mind.on(self.app):
            return "Brain is off (Features → Brain)."
        w = (arg or "").split()
        if len(w) == 3 and w[0] == "effort":
            try:
                ok = plans_tree.set_effort(self.app, w[1], float(w[2]))
            except ValueError:
                ok = False
            return (
                f"Noted: {w[1]} is {w[2]} hours."
                if ok
                else "Use /plan effort <id> <hours> (the id is in brackets in /plan)."
            )
        return mind_plans.view(self.app)

    def model_cmd(self, msg: Incoming, arg: str) -> str:
        if not mind.on(self.app):
            return "Brain is off (Features → Brain)."
        w = (arg or "").split()
        if len(w) == 2 and w[0] == "wrong":
            return tom_model.wrong(self.app, w[1])
        if len(w) == 2 and w[0] == "forget":
            return tom_model.forget(self.app, w[1])
        return tom_model.report(self.app, w[0] if w else None)

    def senses_cmd(self, msg: Incoming, arg: str) -> str:
        if not mind.on(self.app):
            return "Brain is off (Features → Brain)."
        w = (arg or "").split()
        names = ["intero", "activity", *[f"phone.{s}" for s in senses_phone.SENSORS]]
        if w and w[0] == "body":  # its machine's readings, then how they're felt (0.8.8, mind/stimulation.py)
            return senses_intero.report(self.app) + "\n\n" + stimulation.report(self.app)
        if len(w) == 2 and w[0] in ("on", "off"):
            key = w[1] if w[1] in names else (f"phone.{w[1]}" if f"phone.{w[1]}" in names else "")
            if not key:
                return "Senses: " + ", ".join(n.removeprefix("phone.") for n in names)
            self.app.settings.set(f"mind.senses.{key}", w[0] == "on")
            if w[0] == "off":
                senses_store.forget(
                    self.app,
                    None if key in ("intero",) else ("activity" if key == "activity" else "phone:" + key[6:]),
                    today_only=False,
                )
            return f"{key.removeprefix('phone.')}: {w[0]}" + (" (what it kept of it is gone)" if w[0] == "off" else "")
        if w and w[0] == "forget":
            sensor = None if len(w) < 2 else ("activity" if w[1] == "activity" else f"phone:{w[1]}")
            return f"Forgot {senses_store.forget(self.app, sensor)} reading(s) from today."
        if len(w) >= 4 and w[:2] == ["wifi", "label"]:
            return (
                "Labelled."
                if senses_phone.label_wifi(self.app, w[2], " ".join(w[3:]))
                else "That network code or name isn't valid."
            )
        lines = [
            f"- its own machine: {'on' if senses_intero.on(self.app) else 'off'} (/senses body)",
            "- your activity: "
            + (f"on: {senses_activity.today(self.app)}" if senses_activity.on(self.app) else "off (opt-in)"),
        ]
        for s in senses_phone.SENSORS:
            lines.append(
                f"- phone {s}: "
                + ("on: " + senses_phone.today(self.app, s) if senses_phone.enabled(self.app, s) else "off")
            )
        return (
            "What it senses (each opt-in, nothing leaves this computer):\n"
            + "\n".join(lines)
            + "\n/senses off <name> switches one off and deletes what it kept; /senses forget [name] clears today."
        )

    def callbacks(self):
        return {
            "skl": lambda ref, act: skill_demos.button(self.app, ref, act),
            "prec": lambda ref, act: mind_precedents.button(self.app, ref, act),
            "mdr": lambda ref, act: dream.button(self.app, ref, act),  # a dream card or lesson: Keep, Drop, Undo
            "msp": lambda ref, act: study_push.button(self.app, ref, act),  # the morning line: Yes / Later
            "mres": lambda ref, act: tom_results.button(self.app, ref, act),  # more hours for a course's exams
        }

    def intents(self):
        def result(text: str):
            if not mind.part_on(self.app, "tom") or not self.app.settings.get("mind.tom.from_chat"):
                return None
            got = tom_results.parse(text)
            sub = self.app.modules.get("subjects")
            if got is None or sub is None or not self.app.is_on("subjects"):
                return None
            found = sub.find_in(got[2])
            return {"slug": found[0], "f": got[0], "what": got[1]} if len(found) == 1 else None

        def run(msg: Incoming, s: dict) -> str:
            text, offer, buttons = tom_results.take(self.app, s["slug"], s["f"], s["what"])
            if offer:  # the offer of more preparation time comes as its own message, with its buttons
                self.app.notify(offer, kind="question", buttons=buttons, why="asked")
            return text

        return [
            Intent(
                "exam_result",
                "an exam result you got, as evidence of what you know",
                result,
                run,
                examples=("I got 12/30 on the LA midterm",),
            )
        ]

    def precedents_cmd(self, msg: Incoming, arg: str) -> str:
        if not mind.on(self.app):
            return "Brain is off (Features → Brain)."
        w = (arg or "").split()
        if len(w) == 3 and w[0] == "edit":
            return (
                "Changed."
                if mind_precedents.edit(self.app, w[1], w[2])
                else "Use /precedents edit <id> <a|b|both|depends>."
            )
        if len(w) == 2 and w[0] == "delete":
            return "Deleted." if mind_precedents.delete(self.app, w[1]) else "No such precedent."
        return mind_precedents.listing(self.app)

    def play_cmd(self, msg: Incoming, arg: str) -> str:
        if not mind.on(self.app):
            return "Brain is off (Features → Brain)."
        w = (arg or "").split()
        if w[:1] == ["outputs"]:
            return mind_play.outputs(self.app)
        if len(w) == 2 and w[0] == "useful":
            return "Thanks: that counts." if mind_play.useful(self.app, w[1]) else "No such output, or already counted."
        return mind_play.listing(self.app)

    def learned_cmd(self, msg: Incoming, arg: str) -> str | None:
        words = (arg or "").split(None, 2)
        sub = words[0].lower() if words else ""
        learning = self.app.modules.get("learning")
        if learning is not None and self.app.is_on("learning") and sub not in ("run", "retire"):
            return learning._learned(msg, arg)  # noqa: SLF001  one /learned for both lists (modules/learning.py)
        if not mind.on(self.app):
            return "Brain is off (Features → Brain)."
        if len(words) >= 2 and words[0].lower() == "retire":
            return "Retired." if skill_library.retire(self.app, words[1]) else f"There's no active skill {words[1]}."
        if len(words) >= 2 and words[0].lower() == "run":
            m = skill_library.meta(self.app, words[1])
            if not m or m.get("retired"):
                return f"There's no active skill {words[1]}."
            first = (m.get("inputs") or ["text"])[0]
            out = skill_library.run_by_owner(self.app, words[1], {first: words[2] if len(words) > 2 else ""})
            return out or "It gave nothing back."
        return skill_library.listing(self.app)

    def lab_cmd(self, msg: Incoming, arg: str) -> str:
        if not mind.on(self.app):
            return "Brain is off (Features → Brain)."
        if not mind.part_on(self.app, "lab"):
            return "The lab is off (mind.lab.on)."
        words = (arg or "").split()
        sub = words[0].lower() if words else ""
        if sub == "results":
            return lab_report.results(self.app)
        if sub == "add" and len(words) > 1:
            folder = " ".join(words[1:])
            if not Path(folder).expanduser().is_dir():
                return f"There's no folder {folder}."
            cur = list(self.app.settings.get("mind.lab.projects") or [])
            if folder not in cur:
                self.app.settings.set("mind.lab.projects", [*cur, folder])
            return f"Added. Next: /lab protocol {lab_runner.slug(Path(folder).name)}"
        if sub in ("protocol", "run") and len(words) > 1:
            slug = lab_runner.slug(words[1])
            root = lab_runner.projects(self.app).get(slug)
            if root is None:
                return f"{words[1]} isn't a lab project. /lab add <folder> first."
            if sub == "protocol":
                if len(words) > 2 and words[2].lower() == "approve":
                    return lab_runner.approve(self.app, slug, root)
                text, notes = lab_runner.draft(self.app, slug, root)
                st = lab_runner.status(self.app, slug, root)[0]
                where = lab_runner.protocol_file(self.app, slug, root)
                return (
                    f"Protocol for {slug} ({st}), in {where}:\n{text or '(none could be drafted)'}\n"
                    + "".join(f"- {n}\n" for n in notes)
                    + (f"Edit the file if it's off, then /lab protocol {slug} approve." if st != "approved" else "")
                )
            threading.Thread(target=self._lab_now, args=(slug, root), daemon=True).start()
            return f"Started a batch on {slug}; the result comes as a message (it runs when the computer can spare it)."
        return lab_report.listing(self.app)

    def _lab_now(self, slug: str, root) -> None:
        res = lab_runner.run_batch(self.app, slug, root)
        if res.get("finished"):
            self.app.notify(lab_report.batch_line(slug, res["analysis"], res["baseline"]), kind="result", why="asked")
        else:
            self.app.notify(f"{slug}: {res.get('why') or 'nothing ran'}.", kind="info", why="asked")

    def improve_cmd(self, msg: Incoming, arg: str) -> str:
        if not mind.on(self.app):
            return "Brain is off (Features → Brain)."
        words = (arg or "").split()
        if len(words) == 2 and words[0].lower() == "promote":
            return improve.promote(self.app, words[1])
        return improve.listing(self.app)

    def thinking_cmd(self, msg: Incoming, arg: str) -> str:
        if not mind.on(self.app):
            return "Brain is off (Features → Brain)."
        words = (arg or "").split()
        acts = {
            "pin": workspace.pin,
            "unpin": workspace.unpin,
            "mute": workspace.mute,
            "veto": workspace.veto,
            "unveto": workspace.unveto,
        }
        if len(words) == 2 and words[0].lower() in acts:
            return acts[words[0].lower()](self.app, words[1])
        return attention.report(self.app)

    def beliefs_cmd(self, msg: Incoming, arg: str) -> str:
        return beliefs.report(self.app, arg or "") if mind.on(self.app) else "Brain is off (Features → Brain)."

    def wake_cmd(self, msg: Incoming, arg: str) -> str:
        """(0.8.18) /wake: awake for mind.sleep.wake_minutes; asleep, nothing listens, so this (or a message, a tap, a
        call) is how it's woken."""
        if not sleep.on(self.app):
            return "I'm awake: sleep is off (mind.sleep.on)."
        was = sleep.state(self.app)
        mins = sleep._wake_minutes(self.app)
        sleep.wake(self.app, "you said /wake", mins)
        if was != "asleep":
            return f"I'm awake. {sleep.line(self.app)}"
        return f"Awake: camera and microphone on, for at least {mins} min."

    def promises_cmd(self, msg: Incoming, arg: str) -> str:
        return promises.listing(self.app) if mind.on(self.app) else "Brain is off (Features → Brain)."

    def mood_cmd(self, msg: Incoming, arg: str) -> str | None:
        text, buttons = mood.view(self.app)
        msg.reply(text, buttons or None)
        return None

    def cmd(self, msg: Incoming, arg: str) -> str:
        c = mind.connect(self.app)
        if (arg or "").strip().lower() == "learning":
            from kurooto.mind import report

            return report.learning_text(self.app)
        if (arg or "").strip().lower() == "gate":
            text, buttons = gate.status(self.app)
            msg.reply(text, buttons or None)
            return None
        if (arg or "").strip().lower() in ("measures", "measurements"):
            return _console.measures_text(self.app)
        words = (arg or "").split()
        if words and words[0].lower() == "backfill":
            return self.backfill(words[1:])
        if (arg or "").strip().lower() == "verify":
            r = c.verify()
            if r.ok:
                return f"Brain's log checks out: {r.records:,} records, every one in its place (#{r.head})."
            return f"Brain's log doesn't check out at #{r.first_bad_seq}: {r.why}. /mind says more."
        return self.status(c)

    def backfill(self, words: list[str]) -> str:
        """/mind backfill [dry | run [source] | verify | forget [source]]: feed Brain what Kurooto kept before it was
        on (mind/history.py)."""
        from kurooto.mind import history

        sub = words[0].lower() if words else "status"
        src = words[1].lower() if len(words) > 1 else ""
        if src and src not in history.SOURCES:
            return f"No source {src!r}. Sources: {', '.join(history.SOURCES)}."
        if sub == "forget":
            n = history.forget(self.app, src)
            return f"Forgot {n:,} imported rows" + (f" from {src}." if src else ".")
        if sub in ("dry", "dry-run", "plan"):
            p = history.plan(self.app)
            if not p["rows"]:
                return "Nothing to import: nothing from before Brain was on."
            span = f"{dt.datetime.fromtimestamp(p['from']):%d %b} to {dt.datetime.fromtimestamp(p['to']):%d %b}"
            per = ", ".join(f"{s} {v['rows']:,}" for s, v in p["sources"].items() if v["rows"])
            return f"Would import {p['rows']:,} rows ({span}): {per}. Nothing written. /mind backfill run does it."
        if sub == "verify":
            r = history.verify(self.app)
            n = sum(r["sources"].values())
            if r["ok"]:
                return (
                    f"The imported past checks out: {n:,} rows on {len(r['sources'])} chains, every one in its place."
                )
            b = r["bad"]
            return f"The imported past doesn't check out: {b['source']} #{b['n']}, {b['why']}."
        if sub == "run":
            res = history.run(self.app, only=src)
            bars = "\n".join(res.get("bars") or [])
            if res.get("error"):
                return "\n".join(x for x in (res["error"], bars) if x)
            head = f"Imported {res['rows']:,} rows in {res['batches']} batches."
            if res.get("late"):
                head += f" {res['late']:,} were older than what was already in and were left out."
            return f"{head}\n{bars}\n/mind backfill shows what it learned; /mind backfill verify checks it."
        st = history.status(self.app)
        head = [f"Imported: {st['imported']:,} rows." if st["imported"] else "Nothing imported yet."]
        if not self.app.settings.get("mind.backfill.on"):
            head.append("It's off: turn on mind.backfill.on, then /mind backfill dry and /mind backfill run.")
        return "\n".join([*head, *history.describe(self.app)])

    def status(self, c) -> str:
        st = c.state()
        up, pid = c.running()
        lines = ["Brain is on."]
        if self.hardened():
            lines.append(f"Scorekeeper: {'running' if up else 'not running'} as its own user (hardened mode).")
        elif up:
            lines.append(f"Scorekeeper: running (process {pid}).")
        else:
            lines.append("Scorekeeper: not running right now; it's started again by itself.")
        a = st["anchor"]
        start = int(a["seq"]) if a else 1
        r = c.verify(start)  # quick: from the last anchor (/mind verify checks everything)
        state = "checks out" if r.ok else f"doesn't check out at #{r.first_bad_seq} ({r.why})"
        lines.append(f"Log: {st['records']:,} records, head #{st['head']} {st['hash'][:12]}, {state}.")
        if a:
            when = _when(a.get("at"))
            lines.append(f"Last anchor: #{a['seq']} {str(a['hash'])[:12]}{f', {when}' if when else ''}.")
        lines += [sleep.line(self.app), senses_intero.yield_line(self.app)]
        scored = sum(st["scores"].values())
        lines.append("Scores: none yet." if not scored else f"Scores: {scored} kept.")
        if st["waiting"]:
            lines.append(f"Waiting to be logged: {st['waiting']} (kept aside until the scorekeeper takes them).")
        if st["dropped"]:
            lines.append(f"Dropped since Kurooto started: {st['dropped']} (more came than could be kept).")
        try:  # what its dreaming brought, and how the cards are recalled (information only)
            lines += dream.mind_lines(self.app)
        except Exception as e:
            self.app.events.emit("mind_dream_failed", error=type(e).__name__)
        try:  # 0.8.16: each kind of act its trust decides, and the presence forecast's accuracy
            lines += act.kinds_lines(self.app)
            lines.append(presence_forecast.line(self.app))
        except Exception as e:
            self.app.events.emit("mind_status_failed", error=type(e).__name__)
        return "\n".join(x for x in lines if x)


def _when(iso) -> str:
    try:
        t = dt.datetime.fromisoformat(str(iso))
    except (TypeError, ValueError):
        return ""
    return t.strftime("%d %b %H:%M")


def button(app, ref: str, act: str) -> str:
    """Delete Brain's data / Keep it, under the message that Brain is off (a core button: Brain is off by then)."""
    if act != "delete":
        return "Kept."
    try:
        asked = int(ref)
    except ValueError:
        return "That button has expired."
    if time.time() - asked > CONFIRM_S:
        return "That button has expired; turn Brain off again to be asked again."
    if mind.on(app):
        return "Brain is on again, so its data stays. Turn it off first."
    d = app.paths.state / "mind"
    c = mind.connect(app)
    up, _ = c.running()
    if up:
        return "Brain's scorekeeper is still stopping; try again in a minute."
    mind.forget_client(app)
    n = mlog.MindLog(d / "log.db").count() if d.exists() else 0
    shutil.rmtree(d, ignore_errors=True)
    shutil.rmtree(app.paths.state / "mind-journal", ignore_errors=True)  # its journal (mind/journal.py)
    shutil.rmtree(app.paths.state / "mind-story", ignore_errors=True)  # its life story (mind/story.py)
    shutil.rmtree(app.paths.state / "mind-play", ignore_errors=True)  # what it explored in its free time
    shutil.rmtree(app.paths.state / "mind-senses", ignore_errors=True)  # the senses' readings, salt and totals
    shutil.rmtree(app.paths.state / "mind-skills", ignore_errors=True)  # the learned skills and the fine-tune's folder
    shutil.rmtree(app.paths.state / "lab", ignore_errors=True)  # the lab's protocols, pre-registrations and results
    for f in (
        "mind-gate.json",
        "mind-mood.json",
        "mind-tone.json",
        "mind-promises.json",
        "mind-feelings.json",
        "mind-acts.json",
        "mind-workspace.json",
        "mind-beliefs.json",
        "mind-improve.json",
        "mind-distilled.json",
        "mind-demos.json",
        "mind-finetune.json",
        "mind-intero.json",
        "mind-activity.json",
        "mind-tom.json",
        "mind-plans.json",
        "mind-plan-last.json",
        "mind-precedents.json",
        "mind-play.json",
        "mind-pest.json",
        "mind-stimulation.json",
        "mind-sleep.json",
        "mind-dream.json",
        "mind-study-push.json",
        "mind-surprise.json",
        "mind-presence.json",
    ):  # the gate's, the read's, the tone's, its promises' and its acts' own files
        (app.paths.state / f).unlink(missing_ok=True)
    app.events.emit("mind_deleted", records=n)
    return "Deleted Brain's data." if not d.exists() else "Couldn't delete all of it; /mind says what's left."
