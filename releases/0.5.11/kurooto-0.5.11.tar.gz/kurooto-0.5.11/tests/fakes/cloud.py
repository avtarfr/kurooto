"""Fake cloud services for the call line's local test: Gemini's token endpoint, ntfy, and a Web Push endpoint.
They record what they're sent.

Gemini Live being down: models in `live_down` answer the token request 503 UNAVAILABLE, as Google did, and models in
`live_errors` answer with that error (404 for one that's gone). Turn-by-turn
calls answered on the call line: `gen_script` holds the next generateContent answers, each {"text": ...} or
{"call": (name, args)}; when it's empty the answer is `transcript` (what voice notes expect)."""

from __future__ import annotations

import json
import re
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


class FakeCloud:
    def __init__(self):
        self.tokens: list[dict] = []  # Gemini auth_tokens requests
        self.ntfy: list[dict] = []
        self.pushes: list[dict] = []
        self.ntfy_down = False  # ntfy refuses messages (they aren't recorded)
        self.generate: list[dict] = []  # Gemini generateContent (voice notes)
        self.transcript = "remind me at nine to call home"
        self.live_down: set[str] = set()
        self.live_errors: dict[str, tuple] = {}  # model -> (code, status, message), e.g. a model that's gone (404)
        self.gen_script: list[dict] = []
        fake = self

        class H(BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def do_GET(self):
                if self.path.startswith("/models"):  # checking a Gemini key
                    if self.headers.get("x-goog-api-key") == "good-key":
                        return self._json({"models": [{"name": "models/x"}]})
                    self.send_response(400)
                    self.end_headers()
                    return None
                self.send_response(404)
                self.end_headers()
                return None

            def do_POST(self):
                raw = self.rfile.read(int(self.headers.get("Content-Length") or 0))
                hdrs = {k.lower(): v for k, v in self.headers.items()}
                if self.path.endswith("/auth_tokens"):
                    fake.tokens.append({"headers": hdrs, "body": json.loads(raw or b"{}")})
                    model = re.search(r'"models/([\w.-]+)"', raw.decode())
                    model = model.group(1) if model else ""
                    if model in fake.live_down:
                        err = {"code": 503, "message": "The service is currently unavailable.", "status": "UNAVAILABLE"}
                        return self._json({"error": err}, 503)
                    if model in fake.live_errors:
                        code, status, message = fake.live_errors[model]
                        return self._json({"error": {"code": code, "message": message, "status": status}}, code)
                    return self._json({"name": f"auth_tokens/fake-{len(fake.tokens)}"})
                if ":generateContent" in self.path:
                    fake.generate.append({"path": self.path, "headers": hdrs, "body": json.loads(raw or b"{}")})
                    step = fake.gen_script.pop(0) if fake.gen_script else {"text": fake.transcript}
                    if "call" in step:
                        name, args = step["call"]
                        part = {"functionCall": {"name": name, "args": args, "id": f"fc{len(fake.generate)}"}}
                    else:
                        part = {"text": step["text"]}
                    return self._json({"candidates": [{"content": {"role": "model", "parts": [part]}}]})
                if self.path.startswith("/push/"):
                    fake.pushes.append({"path": self.path, "headers": hdrs, "len": len(raw)})
                    self.send_response(201)
                    self.end_headers()
                    return None
                if self.path == "/" and fake.ntfy_down:
                    self.send_response(503)
                    self.end_headers()
                    return None
                if self.path == "/":
                    fake.ntfy.append(json.loads(raw or b"{}"))
                    return self._json({"id": str(len(fake.ntfy))})
                self.send_response(404)
                self.end_headers()
                return None

            def _json(self, obj, code=200):
                body = json.dumps(obj).encode()
                self.send_response(code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

        self.server = ThreadingHTTPServer(("127.0.0.1", 0), H)
        self.base = f"http://127.0.0.1:{self.server.server_address[1]}"
        threading.Thread(target=self.server.serve_forever, daemon=True).start()

    def close(self):
        self.server.shutdown()
        self.server.server_close()
